"use client"

import React from 'react'
import {
    Sidebar,
    SidebarContent,
    SidebarFooter,
    SidebarGroup,
    SidebarGroupContent,
    SidebarGroupLabel,
    SidebarHeader,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem,
    SidebarRail,
    useSidebar,
} from "@/components/ui/sidebar"

import {
    Calendar,
    Home,
    MessageSquare,
    Megaphone,
    Settings,
    Wallet,
    Book,
    ShoppingCart,
    History,
    CreditCard,
    ChevronLeft,
    ChevronRight
} from "lucide-react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import { useUser, useClerk } from "@clerk/nextjs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

const items = [
    {
        title: "Dashboard",
        url: "/dashboard",
        icon: Home,
    },
    {
        title: "Announcements",
        url: "/announcements",
        icon: Megaphone,
    },
    {
        title: "Assignments",
        url: "/assignments",
        icon: Book,
    },
    {
        title: "Market",
        url: "/market",
        icon: ShoppingCart,
        subItems: [
            {
                title: "Orders History",
                url: "/market/orders",
                icon: History,
            }
        ]
    },
    {
        title: "Wallet",
        url: "/wallet",
        icon: Wallet,
        subItems: [
            {
                title: "Payment History",
                url: "/wallet/payments",
                icon: CreditCard,
            }
        ]
    },
    {
        title: "Chat",
        url: "/chat",
        icon: MessageSquare,
    },
    {
        title: "Calendar",
        url: "/calendar",
        icon: Calendar,
    },
]

export function AppSidebar() {
    const pathname = usePathname()
    const { user } = useUser()
    const { openUserProfile } = useClerk()
    const { state, toggleSidebar } = useSidebar()

    return (
        <Sidebar collapsible="icon">
            <SidebarHeader>
                <div className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-2 min-w-0">
                        <div className="flex h-7 w-7 items-center justify-center rounded bg-foreground text-background font-bold text-lg shrink-0">
                            B
                        </div>
                        <span className="font-bold text-xl tracking-tight truncate group-data-[collapsible=icon]:hidden">Bbrains</span>
                    </div>
                    
                    {/* Collapsible button on the right side of the sidebar */}
                    <Button
                        variant="ghost"
                        size="icon"
                        onClick={toggleSidebar}
                        className="h-8 w-8 shrink-0"
                        title={state === "expanded" ? "Collapse sidebar" : "Expand sidebar"}
                    >
                        {state === "expanded" ? (
                            <ChevronLeft className="h-4 w-4" />
                        ) : (
                            <ChevronRight className="h-4 w-4" />
                        )}
                    </Button>
                </div>
            </SidebarHeader>

            <SidebarContent>
                <SidebarGroup>
                    <SidebarGroupLabel className="px-2 pb-2 text-xs font-bold text-gray-500 uppercase tracking-tighter group-data-[collapsible=icon]:hidden">
                        Menu
                    </SidebarGroupLabel>
                    <SidebarGroupContent>
                        <SidebarMenu>
                            {items.map((item) => (
                                <React.Fragment key={item.url}>
                                    {/* Parent item */}
                                    <SidebarMenuItem>
                                        <SidebarMenuButton asChild>
                                            <Link
                                                href={item.url}
                                                className={pathname === item.url ? "bg-gray-100 dark:bg-gray-800" : ""}
                                            >
                                                <item.icon className="h-4 w-4" />
                                                <span className="group-data-[collapsible=icon]:hidden">{item.title}</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>

                                    {/* Sub-items — hidden when sidebar is collapsed to icon mode */}
                                    {item.subItems && item.subItems.length > 0 && (
                                        <div className="group-data-[collapsible=icon]:hidden">
                                            <SidebarMenu>
                                                {item.subItems.map((subItem) => (
                                                    <SidebarMenuItem key={subItem.url} className="ml-4">
                                                        <SidebarMenuButton asChild>
                                                            <Link
                                                                href={subItem.url}
                                                                className={pathname === subItem.url ? "bg-gray-100 dark:bg-gray-800" : ""}
                                                            >
                                                                <subItem.icon className="h-4 w-4" />
                                                                <span>{subItem.title}</span>
                                                            </Link>
                                                        </SidebarMenuButton>
                                                    </SidebarMenuItem>
                                                ))}
                                            </SidebarMenu>
                                        </div>
                                    )}
                                </React.Fragment>
                            ))}
                        </SidebarMenu>
                    </SidebarGroupContent>
                </SidebarGroup>
            </SidebarContent>

            <SidebarFooter>
                {user && (
                    <div className="p-2 flex items-center gap-2 mb-2">
                        <Avatar className="h-9 w-9 border shadow-sm shrink-0">
                            <AvatarImage src={user.imageUrl} />
                            <AvatarFallback className="bg-primary/10 text-primary font-bold text-xs">
                                {user.firstName?.[0]}{user.lastName?.[0]}
                            </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
                            <p className="text-sm font-bold truncate text-foreground leading-tight">
                                {user.fullName || user.username || "Anonymous User"}
                            </p>
                            <p className="text-[10px] text-muted-foreground truncate leading-tight mt-0.5">
                                {user.primaryEmailAddress?.emailAddress}
                            </p>
                        </div>
                        <button
                            onClick={() => openUserProfile()}
                            className="p-2 hover:bg-muted rounded-md transition-colors group-data-[collapsible=icon]:hidden shrink-0"
                            title="Open Settings"
                        >
                            <Settings className="h-4 w-4 text-muted-foreground" />
                        </button>
                    </div>
                )}
            </SidebarFooter>
            
            <SidebarRail />
        </Sidebar>
    )
}


