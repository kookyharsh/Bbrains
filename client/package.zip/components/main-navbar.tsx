"use client"

import * as React from "react"
import { UserButton } from "@clerk/nextjs"
import { Bell } from "lucide-react"

import { ModeToggle } from "./mode-toggle"

export function MainNavbar() {
    return (
        <nav className="sticky top-0 z-50 hidden md:flex h-15 w-full items-center border-b bg-background/95 backdrop-blur supports-backdrop-filter:bg-background/60">
            {/* Left Section: Brand */}
            <div className="flex h-full items-center px-4 gap-4 mr-2">
                <div className="flex items-center gap-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded bg-foreground text-background font-bold text-lg">
                        B
                    </div>
                    <span className="font-bold text-xl tracking-tight">Bbrains</span>
                </div>
            </div>

            {/* Center Section - College Name */}
            <div className="flex-1 px-6 flex justify-center">
                <h1 className="text-lg font-semibold text-muted-foreground hidden md:block truncate">
                    Your College Name
                </h1>
            </div>

            {/* Right Section - Notifications, Theme & Profile */}
            <div className="flex items-center gap-4 px-6 border-l h-full shrink-0">
                <ModeToggle />
                <button className="relative p-2 text-muted-foreground hover:bg-muted rounded-full transition-colors">
                    <Bell className="h-5 w-5" />
                    <span className="absolute top-2 right-2 h-2 w-2 bg-destructive rounded-full border-2 border-background"></span>
                </button>

                <div className="flex items-center gap-3 pl-2">
                    <UserButton
                        afterSignOutUrl="/"
                        appearance={{
                            elements: {
                                avatarBox: "h-9 w-9"
                            }
                        }}
                    />
                </div>
            </div>
        </nav>
    )
}
