"use client"

import React, { useMemo } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Copy, Pencil, Reply, Trash2 } from "lucide-react"
import type { Message } from "../data"
import { getAvatarColor, getInitials } from "../utils"
import { UserBadge } from "./ChatPirmitives"

interface MessageItemProps {
    msg: Message
    currentUserId?: string | null
    currentUsername?: string | null
    onReply: (message: Message) => void
    onCopy: (content: string) => void
    onEdit: (message: Message) => void
    onDelete: (messageId: string, withShift: boolean) => void
    onOpenProfile: (userId: string) => void
}

export const MessageItem = React.memo(function MessageItem({
    msg,
    currentUserId,
    currentUsername,
    onReply,
    onCopy,
    onEdit,
    onDelete,
    onOpenProfile,
}: MessageItemProps) {
    const isOwnMessage = currentUserId === msg.user.id
    const isMentioned = Boolean(
        currentUsername &&
        msg.mentions?.some((mention) => mention.toLowerCase() === currentUsername.toLowerCase())
    )

    const content = useMemo(() => {
        if (!msg.mentions?.length) return <>{msg.content}</>

        return (
            <>
                {msg.content.split(/(@[a-zA-Z0-9_]+)/g).map((part, i) =>
                    /^@[a-zA-Z0-9_]+$/.test(part) ? (
                        <span
                            key={i}
                            className="rounded bg-primary/10 px-0.5 font-bold text-primary"
                        >
                            {part}
                        </span>
                    ) : (
                        <React.Fragment key={i}>{part}</React.Fragment>
                    )
                )}
            </>
        )
    }, [msg.content, msg.mentions])

    return (
        <div
            className={`group relative flex gap-4 px-4 py-1.5 hover:bg-muted/50 ${isMentioned ? "bg-primary/5" : ""}`}
        >
            <Avatar
                className="mt-0.5 h-10 w-10 shrink-0 cursor-pointer rounded-full border border-border shadow-sm"
                onClick={() => onOpenProfile(msg.user.id)}
            >
                <AvatarImage src={msg.user.avatar || undefined} alt={msg.user.name} />
                <AvatarFallback className={`text-xs font-bold text-white ${getAvatarColor(msg.user.name)}`}>
                    {getInitials(msg.user.name)}
                </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-1">
                    <span
                        className="cursor-pointer text-sm font-semibold text-foreground hover:underline"
                        onClick={() => onOpenProfile(msg.user.id)}
                    >
                        {msg.user.name}
                    </span>
                    {msg.user.badge && (
                        <UserBadge text={msg.user.badge} color={msg.user.badgeColor!} />
                    )}
                    <span className="text-[11px] font-medium text-muted-foreground">{msg.timestamp}</span>
                    {msg.editedAt && <span className="text-[10px] text-muted-foreground">(edited)</span>}
                </div>
                {msg.replyTo && (
                    <p className="mt-1 truncate border-l-2 border-border pl-2 text-xs text-muted-foreground">
                        Replying to @{msg.replyTo.username}: {msg.replyTo.content}
                    </p>
                )}
                <p className="mt-0.5 text-sm leading-relaxed text-foreground/90 wrap-break-word whitespace-pre-wrap">
                    {content}
                </p>
            </div>
            <div className="pointer-events-none absolute right-4 top-0 z-10 translate-y-[-40%] opacity-0 transition-opacity group-hover:pointer-events-auto group-hover:opacity-100">
                <div className="flex items-center gap-1 rounded-md border bg-popover p-1 shadow-md">
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onReply(msg)} aria-label="Reply">
                        <Reply className="size-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onCopy(msg.content)} aria-label="Copy message">
                        <Copy className="size-3.5" />
                    </Button>
                    {isOwnMessage && (
                        <>
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onEdit(msg)} aria-label="Edit message">
                                <Pencil className="size-3.5" />
                            </Button>
                            <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-destructive hover:text-destructive"
                                onClick={(event) => onDelete(msg.id, event.shiftKey)}
                                aria-label="Delete message"
                            >
                                <Trash2 className="size-3.5" />
                            </Button>
                        </>
                    )}
                </div>
            </div>
        </div>
    )
})
