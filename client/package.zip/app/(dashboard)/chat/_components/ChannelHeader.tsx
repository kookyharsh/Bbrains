"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Hash, Pin, Search, Users } from "lucide-react"

interface ChannelHeaderProps {
    channelName: string
    showMembers: boolean
    onToggleMembers: () => void
}

export function ChannelHeader({ channelName, showMembers, onToggleMembers }: ChannelHeaderProps) {
    return (
        <div className="flex h-12 shrink-0 items-center justify-between border-b border-border bg-background px-4 shadow-sm">
            <div className="flex items-center gap-2">
                <Hash className="size-5 text-muted-foreground" />
                <span className="text-base font-bold text-foreground">{channelName}</span>
            </div>
            <div className="flex items-center gap-2">
                <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:text-foreground"
                    aria-label="Pinned messages"
                >
                    <Pin className="size-5" />
                </Button>
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={onToggleMembers}
                    aria-label="Toggle member list"
                    aria-pressed={showMembers}
                    className={`h-8 w-8 transition-colors ${showMembers
                        ? "text-primary"
                        : "text-muted-foreground hover:text-foreground"
                        }`}
                >
                    <Users className="size-5" />
                </Button>
                <div className="relative ml-1 hidden sm:block">
                    <Input
                        placeholder="Search"
                        className="h-7 w-32 rounded-md bg-muted px-2 pr-8 text-xs placeholder:text-muted-foreground outline-none transition-[width] focus:w-48"
                    />
                    <Search className="pointer-events-none absolute right-2 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
                </div>
            </div>
        </div>
    )
}