"use client"

import React, { useMemo } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Crown } from "lucide-react"
import type { Member } from "../data"
import { ROLE_ORDER, ROLE_LABELS } from "../data"
import { getAvatarColor, getInitials } from "../utils"
import { StatusDot, UserBadge } from "./ChatPirmitives"

// ─── Member Row ───────────────────────────────────────────────────────────────

const MemberRow = React.memo(function MemberRow({ member }: { member: Member }) {
    return (
        <div className="group mx-2 flex cursor-pointer items-center gap-3 rounded-md px-2 py-2 transition-colors hover:bg-muted">
            <div className="relative">
                <Avatar
                    className={`h-8 w-8 rounded-full border border-border shadow-sm ${member.status === "offline" ? "opacity-40" : ""}`}
                >
                    <AvatarFallback className={`text-[10px] font-bold text-white ${getAvatarColor(member.name)}`}>
                        {getInitials(member.name)}
                    </AvatarFallback>
                </Avatar>
                <StatusDot status={member.status} />
            </div>
            <div className="flex min-w-0 flex-1 items-center gap-1.5">
                <span
                    className={`truncate text-sm font-medium ${member.status === "offline"
                        ? "text-muted-foreground/60"
                        : "text-muted-foreground group-hover:text-foreground"
                        }`}
                >
                    {member.name}
                </span>
                {member.role === "admin" && (
                    <Crown className="size-3.5 shrink-0 text-yellow-500" />
                )}
                {member.badge && (
                    <UserBadge text={member.badge} color={member.badgeColor!} />
                )}
            </div>
        </div>
    )
})

// ─── Members Sidebar ──────────────────────────────────────────────────────────

interface MembersSidebarProps {
    members: Member[]
    onClose: () => void
}

export const MembersSidebar = React.memo(function MembersSidebar({ members, onClose }: MembersSidebarProps) {
    const grouped = useMemo(
        () =>
            members.reduce<Record<Member["role"], Member[]>>(
                (acc, m) => { acc[m.role].push(m); return acc },
                { admin: [], moderator: [], member: [] }
            ),
        [members]
    )

    return (
        <div
            className={[
                "flex flex-col overflow-y-auto border-l border-border bg-background",
                "absolute inset-0 z-20 w-full",
                "lg:relative lg:inset-auto lg:z-auto lg:w-64 lg:shrink-0 lg:bg-muted/20",
            ].join(" ")}
        >
            {/* Mobile-only header with back button */}
            <div className="flex h-12 shrink-0 items-center gap-2 border-b border-border px-4 lg:hidden">
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={onClose}
                    aria-label="Back to chat"
                    className="h-8 w-8 text-muted-foreground hover:text-foreground"
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth={2}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="size-5"
                    >
                        <path d="M15 18l-6-6 6-6" />
                    </svg>
                </Button>
                <span className="text-base font-bold text-foreground">Members</span>
            </div>

            {ROLE_ORDER.map((role) =>
                grouped[role].length > 0 ? (
                    <React.Fragment key={role}>
                        <div className="px-4 pb-2 pt-6">
                            <h3 className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                                {ROLE_LABELS[role]} — {grouped[role].length}
                            </h3>
                        </div>
                        {grouped[role].map((member) => (
                            <MemberRow key={member.name} member={member} />
                        ))}
                    </React.Fragment>
                ) : null
            )}
        </div>
    )
})