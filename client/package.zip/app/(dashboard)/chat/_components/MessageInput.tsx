"use client"

import React, { useMemo } from "react"
import { Button } from "@/components/ui/button"
import {
    DropdownMenu, DropdownMenuContent, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
    EmojiPicker, EmojiPickerContent, EmojiPickerFooter, EmojiPickerSearch,
} from "@/components/ui/emoji-picker"
import { Plus, Send, Smile, X } from "lucide-react"
import type { Member, Message } from "../data"

interface MessageInputProps {
    message: string
    channelName: string
    members: Member[]
    editingMessageId: string | null
    replyingMessage: Message | null
    onChange: (val: string) => void
    onSend: () => void
    onKeyDown: (e: React.KeyboardEvent<HTMLInputElement>) => void
    onEmojiSelect: (emoji: { emoji: string }) => void
    onCancelEdit: () => void
    onCancelReply: () => void
}

export function MessageInput({
    message, channelName, members, editingMessageId, replyingMessage, onChange, onSend, onKeyDown, onEmojiSelect, onCancelEdit, onCancelReply,
}: MessageInputProps) {
    const mentionMatch = message.match(/(?:^|\s)@([a-zA-Z0-9_]*)$/)
    const mentionQuery = mentionMatch ? mentionMatch[1].toLowerCase() : null

    const mentionCandidates = useMemo(() => {
        if (mentionQuery === null) return []
        return members
            .filter((member) => member.username.toLowerCase().startsWith(mentionQuery))
            .slice(0, 6)
    }, [mentionQuery, members])

    const insertMention = (username: string) => {
        if (mentionQuery === null) return
        onChange(message.replace(/@([a-zA-Z0-9_]*)$/, `@${username} `))
    }

    return (
        <div className="shrink-0 bg-background px-4 pb-6 pt-2">
            {replyingMessage && (
                <div className="mb-2 flex items-center justify-between rounded-md border bg-muted/50 px-3 py-2 text-xs">
                    <span className="truncate">
                        Replying to <span className="font-semibold">{replyingMessage.user.name}</span>: {replyingMessage.content}
                    </span>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onCancelReply}>
                        <X className="size-3.5" />
                    </Button>
                </div>
            )}
            {editingMessageId && (
                <div className="mb-2 flex items-center justify-between rounded-md border bg-muted/50 px-3 py-2 text-xs">
                    <span>Editing message</span>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onCancelEdit}>
                        <X className="size-3.5" />
                    </Button>
                </div>
            )}
            <div className="flex items-center rounded-lg border border-border bg-muted/60 shadow-sm transition-colors focus-within:border-primary/50">
                <Button
                    variant="ghost"
                    size="icon"
                    className="h-11 w-11 shrink-0 text-muted-foreground hover:text-foreground"
                    aria-label="Attach file"
                >
                    <Plus className="size-5" />
                </Button>

                <input
                    value={message}
                    onChange={(e) => onChange(e.target.value)}
                    onKeyDown={onKeyDown}
                    placeholder={`Message #${channelName}`}
                    className="h-11 flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
                    aria-label="Message input"
                />

                <div className="flex items-center gap-1 pr-2">
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-muted-foreground hover:text-foreground"
                                aria-label="Open emoji picker"
                            >
                                <Smile className="size-5" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent
                            align="end"
                            side="top"
                            className="h-100 w-fit border-none bg-transparent p-0 shadow-none"
                        >
                            <EmojiPicker
                                className="h-full border shadow-xl"
                                onEmojiSelect={onEmojiSelect}
                            >
                                <EmojiPickerSearch placeholder="Search emoji…" />
                                <EmojiPickerContent />
                                <EmojiPickerFooter />
                            </EmojiPicker>
                        </DropdownMenuContent>
                    </DropdownMenu>

                    <Button
                        onClick={onSend}
                        disabled={!message.trim()}
                        size="icon"
                        aria-label={editingMessageId ? "Save message" : "Send message"}
                        className="h-8 w-8 bg-primary text-primary-foreground transition-transform hover:scale-105 active:scale-95 disabled:bg-muted disabled:text-muted-foreground"
                    >
                        <Send className="size-4" />
                    </Button>
                </div>
            </div>
            {mentionCandidates.length > 0 && (
                <div className="mt-2 rounded-md border bg-popover p-1 shadow-md">
                    {mentionCandidates.map((member) => (
                        <button
                            key={member.id}
                            type="button"
                            onClick={() => insertMention(member.username)}
                            className="block w-full rounded-sm px-2 py-1 text-left text-xs hover:bg-muted"
                        >
                            <span className="font-medium">{member.name}</span>
                            <span className="ml-2 text-muted-foreground">@{member.username}</span>
                        </button>
                    ))}
                </div>
            )}
        </div>
    )
}
