import type { Member } from "../data"

// ─── Status Dot ───────────────────────────────────────────────────────────────

export function StatusDot({ status }: { status: Member["status"] }) {
    const colors: Record<Member["status"], string> = {
        online: "bg-green-500",
        idle: "bg-yellow-500",
        offline: "bg-muted-foreground",
    }
    return (
        <span
            className={`absolute bottom-0 right-0 block h-3 w-3 rounded-full border-2 border-background ${colors[status]}`}
        />
    )
}

// ─── User Badge ───────────────────────────────────────────────────────────────

export function UserBadge({ text, color }: { text: string; color: string }) {
    return (
        <span
            className={`ml-1 inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-bold uppercase leading-none text-white ${color}`}
        >
            {text}
        </span>
    )
}

// ─── Date Separator ───────────────────────────────────────────────────────────

export function DateSeparator({ date }: { date: string }) {
    return (
        <div className="my-4 flex items-center gap-2 px-4">
            <div className="h-px flex-1 bg-border" />
            <span className="text-[11px] font-semibold text-muted-foreground">{date}</span>
            <div className="h-px flex-1 bg-border" />
        </div>
    )
}