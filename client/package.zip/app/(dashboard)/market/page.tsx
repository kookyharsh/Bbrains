"use client"

import React, { useState, useMemo, useEffect } from "react"
import Link from "next/link"
import { useUser, useAuth } from "@clerk/nextjs"
import { Search, ShoppingCart, Loader2, PlusCircle, Package, ShieldCheck } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import type { Product } from "./types"
import { fetchProducts, addToCart, createProduct } from "./data"
import { ProductCard } from "./_components/ProductCard"

// ─── Market Page ──────────────────────────────────────────────────────────────

export default function MarketPage() {
    const { user } = useUser()
    const { getToken } = useAuth()
    const [searchQuery, setSearchQuery] = useState("")
    const [activeCategory, setActiveCategory] = useState("All")
    const [products, setProducts] = useState<Product[]>([])
    const [loading, setLoading] = useState(true)
    const [createOpen, setCreateOpen] = useState(false)
    const [createName, setCreateName] = useState("")
    const [createDescription, setCreateDescription] = useState("")
    const [createImageUrl, setCreateImageUrl] = useState("")
    const [createPrice, setCreatePrice] = useState("")
    const [createStock, setCreateStock] = useState("")
    const [createCategory, setCreateCategory] = useState("General")
    const [creating, setCreating] = useState(false)

    const userRole = (user?.publicMetadata?.role as string) ?? "student"
    const canCreateProduct = userRole === "admin" || userRole === "teacher"

    // Fetch products from backend
    useEffect(() => {
        async function loadProducts() {
            try {
                setLoading(true)
                const list = await fetchProducts(getToken)
                setProducts(list)
            } catch (err) {
                console.error("Failed to load products:", err)
            } finally {
                setLoading(false)
            }
        }
        loadProducts()
    }, [getToken])

    const categories = useMemo(() => {
        return ["All", ...Array.from(new Set(products.map((p) => p.category)))]
    }, [products])

    const filteredProducts = useMemo(() => {
        return products.filter((p) => {
            const matchesSearch =
                !searchQuery.trim() ||
                p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                p.description.toLowerCase().includes(searchQuery.toLowerCase())
            const matchesCategory = activeCategory === "All" || p.category === activeCategory
            return matchesSearch && matchesCategory
        })
    }, [searchQuery, activeCategory, products])

    // Add to cart handler
    async function handleAddToCart(productId: string) {
        try {
            await addToCart(getToken, {
                productId: parseInt(productId, 10),
                quantity: 1,
            })
            // Could show a toast here
        } catch (err) {
            console.error("Failed to add to cart:", err)
        }
    }

    async function handleCreateProduct() {
        if (!createName.trim() || !createPrice || !createStock) return
        const priceNumber = Number(createPrice)
        const stockNumber = Number(createStock)
        if (Number.isNaN(priceNumber) || Number.isNaN(stockNumber)) return

        try {
            setCreating(true)
            const product = await createProduct(getToken, {
                name: createName.trim(),
                description: createDescription.trim() || undefined,
                price: priceNumber,
                stock: stockNumber,
                imageUrl: createImageUrl.trim() || undefined,
                category: createCategory.trim() || undefined,
            })
            setProducts((prev) => [product, ...prev])
            setCreateName("")
            setCreateDescription("")
            setCreateImageUrl("")
            setCreatePrice("")
            setCreateStock("")
            setCreateCategory("General")
            setCreateOpen(false)
        } catch (err) {
            console.error("Failed to create product:", err)
        } finally {
            setCreating(false)
        }
    }

    return (
        <div className="flex h-full w-full flex-col overflow-hidden bg-background">
            {/* ── Header ── */}
            <div className="shrink-0 border-b border-border bg-background px-4 py-4 space-y-3">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <ShoppingCart className="size-5 text-muted-foreground" />
                        <h1 className="text-base font-bold text-foreground">Campus Market</h1>
                        <Badge variant="secondary" className="text-[10px]">
                            {filteredProducts.length} items
                        </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                        <Link href="/market/my-products">
                            <Button variant="outline" size="sm" className="gap-1.5 rounded-full">
                                <Package className="size-3.5" />
                                My Products
                            </Button>
                        </Link>
                        {canCreateProduct && (
                            <Link href="/market/approvals">
                                <Button variant="outline" size="sm" className="gap-1.5 rounded-full">
                                    <ShieldCheck className="size-3.5" />
                                    Approvals
                                </Button>
                            </Link>
                        )}
                        {canCreateProduct && (
                            <Button
                                size="sm"
                                className="gap-1.5 rounded-full"
                                onClick={() => setCreateOpen(true)}
                            >
                                <PlusCircle className="size-3.5" />
                                List an item
                            </Button>
                        )}
                    </div>
                </div>

                {/* ── Search Bar ── */}
                <div className="relative max-w-md">
                    <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                        placeholder="Search products..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="h-9 pl-9 bg-muted/50"
                    />
                </div>

                {/* ── Category Filters ── */}
                <div className="flex flex-wrap gap-2">
                    {categories.map((cat) => (
                        <Button
                            key={cat}
                            variant={activeCategory === cat ? "default" : "outline"}
                            size="sm"
                            className="h-7 rounded-full text-xs"
                            onClick={() => setActiveCategory(cat)}
                        >
                            {cat}
                        </Button>
                    ))}
                </div>
            </div>

            {/* ── Product List ── */}
            <div className="min-h-0 flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent">
                {loading ? (
                    <div className="flex items-center justify-center py-20">
                        <Loader2 className="size-8 animate-spin text-primary" />
                    </div>
                ) : filteredProducts.length > 0 ? (
                    filteredProducts.map((product) => (
                        <ProductCard key={product.id} product={product} onAddToCart={handleAddToCart} />
                    ))
                ) : (
                    <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
                        <ShoppingCart className="size-10 mb-3 opacity-40" />
                        <p className="text-sm font-medium">No products found</p>
                        <p className="text-xs mt-1">Try adjusting your search or filters</p>
                    </div>
                )}
            </div>

            {/* ── Create Product Dialog (Teacher/Admin) ── */}
            {canCreateProduct && (
                <Dialog open={createOpen} onOpenChange={setCreateOpen}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>List a new item</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-3">
                            <Input
                                placeholder="Item name"
                                value={createName}
                                onChange={(e) => setCreateName(e.target.value)}
                            />
                            <Textarea
                                placeholder="Description"
                                value={createDescription}
                                onChange={(e) => setCreateDescription(e.target.value)}
                                rows={3}
                            />
                            <Input
                                placeholder="Image URL (optional)"
                                value={createImageUrl}
                                onChange={(e) => setCreateImageUrl(e.target.value)}
                            />
                            <div className="flex gap-3">
                                <Input
                                    type="number"
                                    placeholder="Price"
                                    value={createPrice}
                                    onChange={(e) => setCreatePrice(e.target.value)}
                                />
                                <Input
                                    type="number"
                                    placeholder="Stock"
                                    value={createStock}
                                    onChange={(e) => setCreateStock(e.target.value)}
                                />
                            </div>
                            <Input
                                placeholder="Category"
                                value={createCategory}
                                onChange={(e) => setCreateCategory(e.target.value)}
                            />
                            <div className="flex justify-end pt-2">
                                <Button
                                    size="sm"
                                    onClick={handleCreateProduct}
                                    disabled={
                                        creating ||
                                        !createName.trim() ||
                                        !createPrice ||
                                        !createStock
                                    }
                                >
                                    {creating ? (
                                        <Loader2 className="mr-2 size-3.5 animate-spin" />
                                    ) : null}
                                    {creating ? "Listing..." : "List item"}
                                </Button>
                            </div>
                        </div>
                    </DialogContent>
                </Dialog>
            )}
        </div>
    )
}
