import Link from "next/link"
import { ShoppingCart } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Product } from "../types"
import { Button } from "@/components/ui/button"
import { StarRating } from "./StarRating"

interface ProductCardProps {
  product: Product
  onAddToCart: (productId: string) => void
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : null

  return (
    <Card className="group overflow-hidden transition-all hover:shadow-lg hover:border-primary/20">
      <div className="flex flex-col sm:flex-row">
        {/* ── Image ── */}
        <Link
          href={`/market/${product.id}`}
          className="relative shrink-0 overflow-hidden bg-muted sm:w-48 h-48"
        >
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-muted to-muted/50 text-muted-foreground group-hover:scale-105 transition-transform duration-300">
            <ShoppingCart className="size-12 opacity-20" />
          </div>
          {product.badge && (
            <Badge className="absolute top-2 left-2 text-[10px] font-bold shadow-sm">
              {product.badge}
            </Badge>
          )}
          {!product.inStock && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-sm">
              <span className="text-sm font-bold text-destructive">Out of Stock</span>
            </div>
          )}
        </Link>

        {/* ── Details ── */}
        <div className="flex flex-1 flex-col justify-between p-4">
          <div>
            <div className="flex items-start justify-between gap-2">
              <Link href={`/market/${product.id}`} className="group/title">
                <h3 className="text-sm font-bold text-foreground group-hover/title:text-primary group-hover/title:underline line-clamp-2">
                  {product.name}
                </h3>
              </Link>
              <Badge variant="secondary" className="shrink-0 text-[10px]">
                {product.category}
              </Badge>
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground line-clamp-2 leading-relaxed">
              {product.description}
            </p>
            {product.rating > 0 && (
              <div className="mt-2 flex items-center gap-2">
                <StarRating rating={product.rating} />
                <span className="text-[11px] text-muted-foreground">
                  {product.rating} ({product.reviews})
                </span>
              </div>
            )}
          </div>

          <div className="mt-3 flex items-end justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-bold text-foreground">
                ₹{product.price.toLocaleString()}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-muted-foreground line-through">
                  ₹{product.originalPrice.toLocaleString()}
                </span>
              )}
              {discountPercent && (
                <span className="text-xs font-bold text-green-600 dark:text-green-400">
                  {discountPercent}% off
                </span>
              )}
            </div>
            <Button
              size="sm"
              disabled={!product.inStock}
              className="gap-1.5 rounded-lg"
              onClick={() => onAddToCart(product.id)}
            >
              <ShoppingCart className="size-3.5" />
              Add to Cart
            </Button>
          </div>
        </div>
      </div>
    </Card>
  )
}

