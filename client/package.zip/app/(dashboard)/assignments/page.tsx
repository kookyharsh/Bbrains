"use client"

import React, { useState, useMemo, useEffect } from "react"
import { useAuth } from "@clerk/nextjs"
import { getAuthedClient } from "@/lib/http"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
    Search, BookOpen, Upload, Eye, CheckCircle2, Clock, ChevronDown,
    CalendarDays, Filter, Loader2
} from "lucide-react"

// ─── Types ────────────────────────────────────────────────────────────────────

interface ApiAssignment {
    id: number
    courseId: number
    title: string
    description?: string
    content?: string
    file?: string
    dueDate: string
    createdAt: string
    course?: { name: string }
}

interface Assignment {
    id: string
    title: string
    description: string
    category: string
    type: string
    dueDate: string
    priority: "high" | "medium" | "low"
    status: "active" | "completed"
    submittedDate?: string
    grade?: string
}

function getPriority(dueDate: string): "high" | "medium" | "low" {
    const now = new Date()
    const due = new Date(dueDate)
    const diffDays = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    if (diffDays < 0) return "high"
    if (diffDays <= 3) return "high"
    if (diffDays <= 7) return "medium"
    return "low"
}

function mapApiAssignment(a: ApiAssignment): Assignment {
    const now = new Date()
    const due = new Date(a.dueDate)
    const isPast = due < now
    return {
        id: String(a.id),
        title: a.title,
        description: a.description || "",
        category: a.course?.name || "General",
        type: "Assignment",
        dueDate: a.dueDate,
        priority: getPriority(a.dueDate),
        status: isPast ? "completed" : "active",
    }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatDate(dateStr: string) {
    return new Date(dateStr).toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
    })
}

function getDaysRemaining(dateStr: string) {
    const diff = new Date(dateStr).getTime() - Date.now()
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24))
    if (days < 0) return "Overdue"
    if (days === 0) return "Due today"
    if (days === 1) return "Due tomorrow"
    return `${days} days left`
}

const priorityConfig: Record<string, { color: string; bg: string }> = {
    high: { color: "text-red-600 dark:text-red-400", bg: "bg-red-500/10" },
    medium: { color: "text-yellow-600 dark:text-yellow-400", bg: "bg-yellow-500/10" },
    low: { color: "text-green-600 dark:text-green-400", bg: "bg-green-500/10" },
}

// ─── Assignment Card ──────────────────────────────────────────────────────────

function AssignmentCard({ assignment }: { assignment: Assignment }) {
    const isActive = assignment.status === "active"
    const pConfig = priorityConfig[assignment.priority]
    const daysText = isActive ? getDaysRemaining(assignment.dueDate) : `Submitted`

    return (
        <Card className="overflow-hidden transition-all hover:shadow-md hover:border-primary/20">
            <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                            <Badge variant="secondary" className="text-[10px]">
                                {assignment.category}
                            </Badge>
                            {isActive && (
                                <Badge className={`text-[10px] ${pConfig.bg} ${pConfig.color} border-0`}>
                                    {assignment.priority.toUpperCase()}
                                </Badge>
                            )}
                            {!isActive && assignment.grade && (
                                <Badge className="text-[10px] bg-green-500/10 text-green-600 dark:text-green-400 border-0">
                                    Grade: {assignment.grade}
                                </Badge>
                            )}
                        </div>
                        <h3 className="text-sm font-bold text-foreground line-clamp-1">{assignment.title}</h3>
                        <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{assignment.description}</p>
                        <div className="flex items-center gap-3 mt-2">
                            <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                                <CalendarDays className="size-3" />
                                {formatDate(assignment.dueDate)}
                            </span>
                            <span className={`flex items-center gap-1 text-[11px] font-semibold ${isActive ? pConfig.color : "text-muted-foreground"
                                }`}>
                                {isActive ? <Clock className="size-3" /> : <CheckCircle2 className="size-3" />}
                                {daysText}
                            </span>
                        </div>
                    </div>
                    <Button
                        size="sm"
                        variant={isActive ? "default" : "outline"}
                        className="shrink-0 gap-1.5"
                    >
                        {isActive ? (
                            <>
                                <Upload className="size-3.5" />
                                Submit
                            </>
                        ) : (
                            <>
                                <Eye className="size-3.5" />
                                View
                            </>
                        )}
                    </Button>
                </div>
            </CardContent>
        </Card>
    )
}

// ─── Assignments Page ─────────────────────────────────────────────────────────

export default function AssignmentsPage() {
    const { getToken } = useAuth()
    const [searchQuery, setSearchQuery] = useState("")
    const [categoryFilter, setCategoryFilter] = useState("All")
    const [assignments, setAssignments] = useState<Assignment[]>([])
    const [loading, setLoading] = useState(true)
    const [showCompleted, setShowCompleted] = useState(false)
    const [visibleCompleted, setVisibleCompleted] = useState(5)

    // Fetch assignments from backend
    useEffect(() => {
        async function fetchAssignments() {
            try {
                setLoading(true)
                const client = await getAuthedClient(getToken)
                const res = await client.get<{ success: boolean; data: ApiAssignment[] }>(
                    "/academic/assignments"
                )
                setAssignments(res.data.data.map(mapApiAssignment))
            } catch (err) {
                console.error("Failed to load assignments:", err)
            } finally {
                setLoading(false)
            }
        }
        fetchAssignments()
    }, [getToken])

    const categories = useMemo(() => {
        return ["All", ...Array.from(new Set(assignments.map(a => a.category)))]
    }, [assignments])

    const activeAssignments = useMemo(() => {
        return assignments.filter(a => {
            if (a.status !== "active") return false
            if (categoryFilter !== "All" && a.category !== categoryFilter) return false
            if (searchQuery.trim()) {
                const q = searchQuery.toLowerCase()
                return a.title.toLowerCase().includes(q) || a.description.toLowerCase().includes(q)
            }
            return true
        })
    }, [assignments, categoryFilter, searchQuery])

    const completedAssignments = useMemo(() => {
        return assignments.filter(a => {
            if (a.status !== "completed") return false
            if (categoryFilter !== "All" && a.category !== categoryFilter) return false
            if (searchQuery.trim()) {
                const q = searchQuery.toLowerCase()
                return a.title.toLowerCase().includes(q) || a.description.toLowerCase().includes(q)
            }
            return true
        })
    }, [assignments, categoryFilter, searchQuery])

    if (loading) {
        return (
            <div className="flex h-full items-center justify-center">
                <Loader2 className="size-8 animate-spin text-primary" />
            </div>
        )
    }

    return (
        <div className="flex h-full w-full flex-col overflow-hidden bg-background">
            {/* ── Header ── */}
            <div className="shrink-0 border-b border-border bg-background px-4 py-4 space-y-3">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <BookOpen className="size-5 text-muted-foreground" />
                        <h1 className="text-base font-bold text-foreground">Assignments</h1>
                        <Badge variant="secondary" className="text-[10px]">
                            {activeAssignments.length} active
                        </Badge>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <div className="relative flex-1 max-w-sm">
                        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                            placeholder="Search assignments..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="h-9 pl-9 bg-muted/50"
                        />
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                        {categories.map((cat) => (
                            <Button
                                key={cat}
                                variant={categoryFilter === cat ? "default" : "outline"}
                                size="sm"
                                className="h-7 rounded-full text-xs"
                                onClick={() => setCategoryFilter(cat)}
                            >
                                {cat}
                            </Button>
                        ))}
                    </div>
                </div>
            </div>

            {/* ── Content ── */}
            <div className="min-h-0 flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent">
                {/* Active Assignments */}
                <div>
                    <h2 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
                        <Clock className="size-4 text-primary" />
                        Active Assignments ({activeAssignments.length})
                    </h2>
                    {activeAssignments.length > 0 ? (
                        <div className="space-y-2">
                            {activeAssignments.map(a => (
                                <AssignmentCard key={a.id} assignment={a} />
                            ))}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
                            <BookOpen className="size-8 mb-2 opacity-40" />
                            <p className="text-sm font-medium">No active assignments</p>
                            <p className="text-xs mt-1">You're all caught up!</p>
                        </div>
                    )}
                </div>

                {/* Completed Assignments */}
                <div>
                    <button
                        onClick={() => setShowCompleted(!showCompleted)}
                        className="flex items-center gap-2 text-sm font-bold text-foreground mb-3 hover:text-primary transition-colors"
                    >
                        <CheckCircle2 className="size-4 text-green-500" />
                        Completed ({completedAssignments.length})
                        <ChevronDown className={`size-4 transition-transform ${showCompleted ? "rotate-180" : ""}`} />
                    </button>
                    {showCompleted && (
                        <div className="space-y-2">
                            {completedAssignments.slice(0, visibleCompleted).map(a => (
                                <AssignmentCard key={a.id} assignment={a} />
                            ))}
                            {visibleCompleted < completedAssignments.length && (
                                <Button
                                    variant="outline"
                                    size="sm"
                                    className="w-full"
                                    onClick={() => setVisibleCompleted(prev => prev + 5)}
                                >
                                    Load More ({completedAssignments.length - visibleCompleted} remaining)
                                </Button>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
