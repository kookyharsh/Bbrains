import { MainNavbar } from "@/components/main-navbar"
import { AppSidebar } from "@/components/app-sidebar"
import { MobileBottomNav } from "@/components/mobile-bottom-nav"
import {
    SidebarInset,
    SidebarProvider,
} from "@/components/ui/sidebar"
import React from 'react'

function DashboardLayout({ children }: { children: React.ReactNode }) {
    return (
        <SidebarProvider defaultOpen={true} style={{ "--sidebar-top": "68px" } as React.CSSProperties}>
            <div className="flex flex-col h-screen overflow-hidden w-full">
                <header className="fixed inset-x-0 top-0 z-50 h-17 bg-background border-b hidden md:block">
                    <MainNavbar />
                </header>
                <div className="flex flex-1 md:pt-17 min-h-0 overflow-hidden">
                    <AppSidebar />
                    <SidebarInset className="overflow-hidden min-h-0">
                        <div className="flex h-0 flex-1 flex-col pb-16 md:pb-0">
                            {children}
                        </div>
                    </SidebarInset>
                </div>

                {/* Mobile Bottom Navigation - hidden on md+ screens */}
                <MobileBottomNav />
            </div>
        </SidebarProvider>
    )
}


export default DashboardLayout
