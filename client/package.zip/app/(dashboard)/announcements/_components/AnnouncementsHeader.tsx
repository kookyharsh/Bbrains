"use client"

import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Megaphone, Search } from "lucide-react"

interface AnnouncementsHeaderProps {
    count: number
    searchQuery: string
    onSearchChange: (val: string) => void
}

export function AnnouncementsHeader({ count, searchQuery, onSearchChange }: AnnouncementsHeaderProps) {
    return (
        <div className="flex h-12 shrink-0 items-center justify-between border-b border-border bg-background px-4 shadow-sm">
            <div className="flex items-center gap-2">
                <Megaphone className="size-5 text-muted-foreground" />
                <span className="text-base font-bold text-foreground">Announcements</span>
                <Badge variant="secondary" className="ml-1 text-[10px]">
                    {count}
                </Badge>
            </div>
            <div className="relative">
                <Input
                    placeholder="Search announcements..."
                    value={searchQuery}
                    onChange={(e) => onSearchChange(e.target.value)}
                    className="h-7 w-40 rounded-md bg-muted px-2 pr-8 text-xs placeholder:text-muted-foreground outline-none transition-[width] focus:w-56"
                />
                <Search className="pointer-events-none absolute right-2 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
            </div>
        </div>
    )
}
