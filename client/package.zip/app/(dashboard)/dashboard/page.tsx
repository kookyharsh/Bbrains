"use client"

import React, { useState, useEffect } from 'react'
import { useAuth } from "@clerk/nextjs"
import { Loader2 } from 'lucide-react'
import { fetchDashboard, DashboardData } from "./data"
import { StatsCards } from "./_components/StatsCards"
import { RecentGrades } from "./_components/RecentGrades"
import { Announcements } from "./_components/Announcements"

// ─── Component ────────────────────────────────────────────────────────────────

export default function DashboardPage() {
    const { getToken } = useAuth()
    const [data, setData] = useState<DashboardData | null>(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)

    useEffect(() => {
        async function loadDashboard() {
            try {
                setLoading(true)
                const dashboard = await fetchDashboard(getToken)
                setData(dashboard)
            } catch (err) {
                setError(err instanceof Error ? err.message : "Failed to load dashboard")
            } finally {
                setLoading(false)
            }
        }
        loadDashboard()
    }, [getToken])

    if (loading) {
        return (
            <div className="flex h-full items-center justify-center">
                <Loader2 className="size-8 animate-spin text-primary" />
            </div>
        )
    }

    if (error || !data) {
        return (
            <div className="flex h-full flex-col items-center justify-center gap-2 text-muted-foreground">
                <p className="text-sm font-medium">Failed to load dashboard</p>
                <p className="text-xs">{error}</p>
            </div>
        )
    }

    const { user, stats, enrollments, recentGrades, announcements } = data
    const displayName = user.userDetails
        ? `${user.userDetails.firstName ?? ''} ${user.userDetails.lastName ?? ''}`.trim() || user.username
        : user.username

    return (
        <div className="p-4 lg:p-8 h-full overflow-y-auto">
            <div className="space-y-6">
                <div className="flex items-center justify-between space-y-2">
                    <h2 className="text-3xl font-bold tracking-tight text-foreground">Welcome, {displayName}</h2>
                </div>

                <StatsCards stats={stats} />

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
                    <RecentGrades recentGrades={recentGrades} />
                    <Announcements announcements={announcements} />
                </div>
            </div>
        </div>
    )
}
