import { Calendar, Filter, Clock, MapPin, Video, Info } from "lucide-react"

export function UpcomingEvents() {
    return (
        <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                    <Calendar className="text-indigo-500 h-5 w-5" />
                    Upcoming Events
                </h3>
                <button className="p-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                    <Filter className="h-4 w-4" />
                </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 xl:gap-6">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-start gap-4 p-4 rounded-xl bg-purple-50 dark:bg-purple-900/10 border border-purple-100 dark:border-purple-900/30">
                    <div className="flex flex-col items-center justify-center w-14 h-14 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-purple-100 dark:border-purple-800 shrink-0">
                        <span className="text-[10px] font-bold text-purple-600 dark:text-purple-400 uppercase">Oct</span>
                        <span className="text-lg font-bold text-gray-900 dark:text-white leading-none mt-0.5">28</span>
                    </div>
                    <div>
                        <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Campus Tech Fair</h4>
                        <div className="flex flex-col gap-1 text-[11px] text-gray-500 font-medium">
                            <span className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" /> 10:00 AM</span>
                            <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> Main Hall</span>
                        </div>
                    </div>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-start gap-4 p-4 rounded-xl bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30">
                    <div className="flex flex-col items-center justify-center w-14 h-14 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-blue-100 dark:border-blue-800 shrink-0">
                        <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase">Nov</span>
                        <span className="text-lg font-bold text-gray-900 dark:text-white leading-none mt-0.5">02</span>
                    </div>
                    <div>
                        <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Guest Lecture: AI</h4>
                        <div className="flex flex-col gap-1 text-[11px] text-gray-500 font-medium">
                            <span className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" /> 2:00 PM</span>
                            <span className="flex items-center gap-1.5"><Video className="h-3.5 w-3.5" /> Online</span>
                        </div>
                    </div>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-start gap-4 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-900/30">
                    <div className="flex flex-col items-center justify-center w-14 h-14 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-emerald-100 dark:border-emerald-800 shrink-0">
                        <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase">Nov</span>
                        <span className="text-lg font-bold text-gray-900 dark:text-white leading-none mt-0.5">15</span>
                    </div>
                    <div>
                        <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Midterm Exams Begin</h4>
                        <div className="flex flex-col gap-1 text-[11px] text-gray-500 font-medium">
                            <span className="flex items-center gap-1.5"><Info className="h-3.5 w-3.5" /> All Campus</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
