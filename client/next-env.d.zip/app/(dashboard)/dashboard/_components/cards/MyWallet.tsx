import { Wallet, ArrowUp, ArrowDown, QrCode, MoreHorizontal } from "lucide-react"

export function MyWallet() {
    return (
        <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800 flex flex-col justify-between">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-base font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                    <Wallet className="text-emerald-500 h-5 w-5" />
                    My Wallet
                </h3>
                <button className="text-gray-400 hover:text-indigo-500 transition-colors">
                    <MoreHorizontal className="h-5 w-5" />
                </button>
            </div>
            <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Total Balance</p>
                <h4 className="text-3xl font-bold text-gray-900 dark:text-white mt-1">2,450 <span className="text-base font-normal text-gray-500">B-Coins</span></h4>
            </div>
            <div className="grid grid-cols-3 gap-3 mt-6">
                <button className="flex flex-col items-center justify-center p-2 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 transition-colors">
                    <ArrowUp className="mb-1 text-indigo-500 h-5 w-5" />
                    <span className="text-xs font-medium">Send</span>
                </button>
                <button className="flex flex-col items-center justify-center p-2 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 transition-colors">
                    <ArrowDown className="mb-1 text-emerald-500 h-5 w-5" />
                    <span className="text-xs font-medium">Receive</span>
                </button>
                <button className="flex flex-col items-center justify-center p-2 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 transition-colors">
                    <QrCode className="mb-1 text-gray-900 dark:text-white h-5 w-5" />
                    <span className="text-xs font-medium">Qr Code</span>
                </button>
            </div>
        </div>
    )
}
