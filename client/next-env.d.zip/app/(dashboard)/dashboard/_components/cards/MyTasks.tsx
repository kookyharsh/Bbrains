import { ClipboardList, Clock, Upload } from "lucide-react"

export function MyTasks() {
    return (
        <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                    <ClipboardList className="text-indigo-500 h-5 w-5" />
                    My Tasks
                </h3>
                <a className="text-sm text-indigo-500 hover:underline" href="#">View All</a>
            </div>
            <div className="space-y-4">
                <div className="group border border-gray-100 dark:border-gray-700 rounded-xl p-4 hover:border-indigo-500 dark:hover:border-indigo-500 transition-colors bg-gray-50/50 dark:bg-gray-800/50">
                    <div className="flex justify-between items-start mb-2">
                        <span className="text-[10px] uppercase tracking-wider font-bold text-indigo-600 bg-indigo-100 dark:bg-indigo-900/30 dark:text-indigo-400 px-2 py-1 rounded-md">Advanced Math</span>
                        <span className="text-[11px] text-red-500 font-medium flex items-center gap-1 bg-red-50 dark:bg-red-900/10 px-2 py-1 rounded-md border border-red-100 dark:border-red-900/30">
                            <Clock className="h-3 w-3" />
                            Due Tomorrow
                        </span>
                    </div>
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Calculus Assignment 4</h4>
                    <p className="text-xs text-gray-500 line-clamp-1 mb-3">Complete chapters 5 to 7 exercises.</p>
                    <button className="w-full flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                        <Upload className="h-4 w-4" />
                        Upload Work
                    </button>
                </div>

                <div className="group border border-gray-100 dark:border-gray-700 rounded-xl p-4 hover:border-indigo-500 dark:hover:border-indigo-500 transition-colors bg-gray-50/50 dark:bg-gray-800/50">
                    <div className="flex justify-between items-start mb-2">
                        <span className="text-[10px] uppercase tracking-wider font-bold text-purple-600 bg-purple-100 dark:bg-purple-900/30 dark:text-purple-400 px-2 py-1 rounded-md">Physics 101</span>
                        <span className="text-[11px] text-gray-500 font-medium flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Oct 29
                        </span>
                    </div>
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Lab Report: Kinematics</h4>
                    <button className="w-full mt-3 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                        <Upload className="h-4 w-4" />
                        Upload Work
                    </button>
                </div>
            </div>
        </div>
    )
}
