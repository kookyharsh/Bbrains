import { Trophy, Flame } from "lucide-react"

export function TopStudents() {
    return (
        <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                    <Trophy className="text-amber-500 h-5 w-5" />
                    Top Students
                </h3>
                <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-1 hidden sm:flex">
                    <button className="px-3 py-1 text-xs font-medium rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm">Weekly</button>
                    <button className="px-3 py-1 text-xs font-medium rounded-md text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">Monthly</button>
                    <button className="px-3 py-1 text-xs font-medium rounded-md text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">All Time</button>
                </div>
            </div>
            <div className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold text-sm shadow-sm shrink-0">1</div>
                        <img alt="Student" className="w-10 h-10 rounded-full border-2 border-white dark:border-gray-800 shrink-0" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBbP3bJ7eEm9ihb4Ut1SAeC2Qp5BOcHmGZC1G8DpGMYTzHg8oOg21vesfkmE6rsyTRnd-Lkf2SJ1CBGxBGjtKPmzQqFqiMrSoVEteNyl76b6dheR1eeq7Fl5XXnX8UsxsV1VdJEgaBoq8IUNro1_ETZiVPRg0mQGgTMQugE8QI9BmVDQMnfwCnCUUP0livipHJO1L1zdf8v2lkRBUOqiuhiO-qmzEHe3XbzD7vtZd0rpu9mlFsldAB_KgtwKyAeboPGHEMPgU45Rvt2" />
                        <div className="min-w-0">
                            <h4 className="text-sm font-semibold text-gray-900 dark:text-white truncate">Sarah Jenkins</h4>
                            <p className="text-xs text-gray-500 truncate">Computer Science</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-4 sm:gap-6 shrink-0">
                        <div className="text-right hidden sm:block">
                            <p className="text-sm font-bold text-gray-900 dark:text-white">12,450</p>
                            <p className="text-[10px] text-gray-500 uppercase tracking-wide">Points</p>
                        </div>
                        <div className="flex items-center gap-1 bg-white dark:bg-gray-800 px-2 py-1 rounded-md shadow-sm border border-gray-100 dark:border-gray-700">
                            <Flame className="text-amber-500 h-4 w-4" />
                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">45</span>
                        </div>
                    </div>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors border border-transparent">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 flex items-center justify-center font-bold text-sm shrink-0">2</div>
                        <img alt="Student" className="w-10 h-10 rounded-full border-2 border-white dark:border-gray-800 shrink-0" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBEnEcqzCaHAr_gs-v05uZZiG4t4A9J-0YiTRM7Ku3St53bwjfNa7lOG1OIVim7jNSsJ4mmmsybO7KkNnFzzikmhgwRm6ARRNx8usiGDZZFXV_Rwc7aRlZHoOZmGl1i91Czzd-8OnQNyzkFct_Myjog30zpEERefuiu-aw3N2ee0DNKSkuLcmcKY537axXUH-ERGjqC2Fk3P6xqt6LHOGxR_TrTT-UjEm1Z-bZhwBdPmhF-FmWqh--6n5Yam_XCpgSKvm0RjDtAWEYv" />
                        <div className="min-w-0">
                            <h4 className="text-sm font-semibold text-gray-900 dark:text-white flex items-center gap-2 truncate">Michael Chang</h4>
                            <p className="text-xs text-gray-500 truncate">Engineering</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-4 sm:gap-6 shrink-0">
                        <div className="text-right hidden sm:block">
                            <p className="text-sm font-bold text-gray-900 dark:text-white">11,200</p>
                            <p className="text-[10px] text-gray-500 uppercase tracking-wide">Points</p>
                        </div>
                        <div className="flex items-center gap-1 bg-white dark:bg-gray-800 px-2 py-1 rounded-md shadow-sm border border-gray-100 dark:border-gray-700">
                            <Flame className="text-amber-500 h-4 w-4" />
                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">32</span>
                        </div>
                    </div>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors border border-transparent">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 flex items-center justify-center font-bold text-sm shrink-0">3</div>
                        <img alt="Student" className="w-10 h-10 rounded-full border-2 border-white dark:border-gray-800 shrink-0" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCwlwlK6Uedy78dcK40sIS1c6oeiiqMbt0FlOSMPInijBmII9Yr6_iWT5bT6L0diSuiU1QtjSREntaBObkyBqTFO6OUR0mxKGpTUFcLspyy-uiFSOe6Lnwb6G_nHTuZsAWIGSdHaHcjCbRA7L-cQY6ihl-s3JHBTC_5mmmsc1qcHHtAOh_s10p_rMuBpUiGn2t56LmFihO5LW6SdBwsRhQu1tFC5AkkYKLMsSOKBBgJf1xbRAk-zuu6O-o3lVC_oNkl2-UgbfWzT_sX" />
                        <div className="min-w-0">
                            <h4 className="text-sm font-semibold text-gray-900 dark:text-white truncate">Emily Davis</h4>
                            <p className="text-xs text-gray-500 truncate">Arts & Design</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-4 sm:gap-6 shrink-0">
                        <div className="text-right hidden sm:block">
                            <p className="text-sm font-bold text-gray-900 dark:text-white">10,850</p>
                            <p className="text-[10px] text-gray-500 uppercase tracking-wide">Points</p>
                        </div>
                        <div className="flex items-center gap-1 bg-white dark:bg-gray-800 px-2 py-1 rounded-md shadow-sm border border-gray-100 dark:border-gray-700">
                            <Flame className="text-amber-500 h-4 w-4" />
                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">28</span>
                        </div>
                    </div>
                </div>

                <div className="relative py-2">
                    <div aria-hidden="true" className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-dashed border-gray-200 dark:border-gray-700"></div>
                    </div>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/20">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-500 flex items-center justify-center font-bold text-sm shrink-0">15</div>
                        <img alt="User" className="w-10 h-10 rounded-full border-2 border-indigo-500 shrink-0" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCDopsLSNFM5T_pAgwvF1YOCzLGz6ZQPYXcr9VJV-eYRlBEJQm2Rhej6e7odWmyLSrUgEvbVO1-gnzyUJoIM0ZAilRC6B7KRrMYhhb5ESIAThzvkscRKajpUWcmdxX9foYg_ivkEJieqxPFYZhLbhiXLRQAYeKq6e4Zb_g6sSlKmpwnZw0FO5cVIMBb6rQ3i-kG8RF1R7-crKUC8HC9pdUdFp1r7Ib0P4badtGd94JwIdNrJEksb3wF-lM7DOjHAQDnD702Y41_QKqY" />
                        <div className="min-w-0">
                            <h4 className="text-sm font-semibold text-indigo-500 truncate">Alex Johnson (You)</h4>
                            <p className="text-xs text-gray-500 truncate">Business Admin</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-4 sm:gap-6 shrink-0">
                        <div className="text-right hidden sm:block">
                            <p className="text-sm font-bold text-gray-900 dark:text-white">5,420</p>
                            <p className="text-[10px] text-gray-500 uppercase tracking-wide">Points</p>
                        </div>
                        <div className="flex items-center gap-1 bg-white dark:bg-gray-800 px-2 py-1 rounded-md shadow-sm border border-gray-100 dark:border-gray-700">
                            <Flame className="text-amber-500 h-4 w-4" />
                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">12</span>
                        </div>
                    </div>
                </div>
            </div>
            <button className="w-full mt-4 py-2 text-sm font-medium text-indigo-500 hover:text-indigo-700 dark:hover:text-indigo-400 transition-colors">
                View Full Leaderboard
            </button>
        </div>
    )
}
