"use client"

import React from 'react'
import {
    Sidebar,
    SidebarContent,
    SidebarFooter,
    SidebarGroup,
    SidebarGroupContent,
    SidebarGroupLabel,
    SidebarHeader,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem,
    SidebarRail,
    useSidebar,
} from "@/components/ui/sidebar"

import {
    Settings,
    BarChart3,
    PanelLeft
} from "lucide-react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import { useUser, useClerk } from "@clerk/nextjs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
    Tooltip,
    TooltipContent,
    TooltipTrigger,
} from "@/components/ui/tooltip"
import { sidebarItems } from "./sidebarData"

export function AppSidebar() {
    const pathname = usePathname()
    const { user } = useUser()
    const { openUserProfile } = useClerk()
    const { state, toggleSidebar } = useSidebar()
    const isCollapsed = state === "collapsed"

    return (
        <Sidebar collapsible="icon" className="border-r border-gray-100 dark:border-gray-800">
            <SidebarHeader className="bg-[#f8f9fa] dark:bg-[#0b0f1a] pt-6 px-3">
                <div className={`flex items-center ${isCollapsed ? "flex-col gap-2" : "justify-between"} mb-6 text-black dark:text-white`}>
                    <div className={`flex items-center ${isCollapsed ? "justify-center" : "gap-3"} min-w-0`}>
                        <div className={`${isCollapsed ? "w-8 h-8" : "w-10 h-10"} bg-black dark:bg-white rounded-xl flex items-center justify-center text-white dark:text-black shrink-0 shadow-sm transition-all duration-200`}>
                            <BarChart3 className={`${isCollapsed ? "h-4 w-4" : "h-6 w-6"} transition-all duration-200`} />
                        </div>
                        {!isCollapsed && (
                            <span className="font-bold text-xl tracking-tight truncate">Bbrains</span>
                        )}
                    </div>

                    {isCollapsed ? (
                        <Tooltip>
                            <TooltipTrigger asChild>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={toggleSidebar}
                                    className="h-7 w-7 shrink-0 text-gray-400 hover:text-gray-900 dark:text-gray-500 dark:hover:text-gray-200 transition-colors"
                                    title="Expand sidebar"
                                >
                                    <PanelLeft className="h-4 w-4" />
                                </Button>
                            </TooltipTrigger>
                            <TooltipContent side="right">Expand</TooltipContent>
                        </Tooltip>
                    ) : (
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={toggleSidebar}
                            className="h-9 w-9 shrink-0 text-gray-400 hover:text-gray-900 dark:text-gray-500 dark:hover:text-gray-200 transition-colors"
                            title="Collapse sidebar"
                        >
                            <PanelLeft className="h-5 w-5" />
                        </Button>
                    )}
                </div>
            </SidebarHeader>

            <SidebarContent className="bg-[#f8f9fa] dark:bg-[#0b0f1a] px-3 custom-scrollbar">
                <SidebarGroup>
                    <SidebarGroupLabel className="px-4 text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-[0.1em] mb-4 group-data-[collapsible=icon]:hidden">
                        Main menu
                    </SidebarGroupLabel>
                    <SidebarGroupContent>
                        <SidebarMenu className="space-y-1.5">
                            {sidebarItems.map((item) => {
                                const isActive = pathname === item.url || pathname.startsWith(`${item.url}/`);
                                return (
                                    <React.Fragment key={item.url}>
                                        <SidebarMenuItem>
                                            <SidebarMenuButton asChild tooltip={item.title}>
                                                <Link
                                                    href={item.url}
                                                    className={`flex items-center gap-3 px-4 py-3 min-h-[48px] rounded-xl transition-all duration-200 ${isActive
                                                        ? "bg-white dark:bg-[#1e293b] text-gray-900 dark:text-white shadow-sm font-semibold"
                                                        : "text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800/50"
                                                        }`}
                                                >
                                                    <item.icon className={`h-5 w-5 shrink-0 ${isActive ? "text-gray-900 dark:text-white" : ""}`} />
                                                    <span className="text-[13px] group-data-[collapsible=icon]:hidden">{item.title}</span>
                                                </Link>
                                            </SidebarMenuButton>
                                        </SidebarMenuItem>

                                        {item.subItems && item.subItems.length > 0 && isActive && (
                                            <div className="group-data-[collapsible=icon]:hidden">
                                                <SidebarMenu className="mt-1 space-y-1">
                                                    {item.subItems.map((subItem) => {
                                                        const isSubActive = pathname === subItem.url;
                                                        return (
                                                            <SidebarMenuItem key={subItem.url} className="ml-10">
                                                                <SidebarMenuButton asChild>
                                                                    <Link
                                                                        href={subItem.url}
                                                                        className={`flex items-center gap-3 py-2 transition-colors text-[12px] ${isSubActive
                                                                            ? "text-gray-900 dark:text-white font-medium"
                                                                            : "text-gray-400 hover:text-gray-900 dark:text-gray-500 dark:hover:text-white"
                                                                            }`}
                                                                    >
                                                                        <span>{subItem.title}</span>
                                                                    </Link>
                                                                </SidebarMenuButton>
                                                            </SidebarMenuItem>
                                                        )
                                                    })}
                                                </SidebarMenu>
                                            </div>
                                        )}
                                    </React.Fragment>
                                )
                            })}
                        </SidebarMenu>
                    </SidebarGroupContent>
                </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className="bg-[#f8f9fa] dark:bg-[#0b0f1a] px-3 pb-6 pt-4 border-t border-gray-100 dark:border-gray-800/50">
                {user && (
                    <div className="flex flex-col gap-4">
                        <button
                            onClick={() => openUserProfile()}
                            className={`flex items-center gap-3 rounded-xl text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors ${isCollapsed ? "justify-center px-0 py-2.5" : "px-4 py-2.5"}`}
                            title="Settings"
                        >
                            <Settings className="h-5 w-5 shrink-0" />
                            {!isCollapsed && (
                                <span className="font-medium text-[13px]">Settings</span>
                            )}
                        </button>

                        <div className={isCollapsed ? "flex justify-center" : "px-2"}>
                            {!isCollapsed && (
                                <h3 className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-[0.1em] mb-4">Account</h3>
                            )}
                            <div className={`flex items-center ${isCollapsed ? "justify-center" : "gap-3"}`}>
                                <Avatar className={`${isCollapsed ? "h-8 w-8" : "h-10 w-10"} rounded-full object-cover ring-2 ring-gray-100 dark:ring-gray-800 shrink-0 transition-all duration-200`}>
                                    <AvatarImage src={user.imageUrl} />
                                    <AvatarFallback className="bg-primary/10 text-primary font-bold text-xs uppercase">
                                        {user.firstName?.[0]}{user.lastName?.[0]}
                                    </AvatarFallback>
                                </Avatar>
                                {!isCollapsed && (
                                    <div className="flex-1 min-w-0">
                                        <p className="text-[13px] font-bold text-gray-900 dark:text-white truncate">
                                            {user.fullName || user.username || "Anonymous User"}
                                        </p>
                                        <p className="text-[11px] text-gray-500 dark:text-gray-500 truncate mt-0.5">
                                            Student
                                        </p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </SidebarFooter>

            <SidebarRail />
        </Sidebar>
    )
}
