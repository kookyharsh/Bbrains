import { AppError } from '../utils/errors.js';
import { ZodError } from 'zod';

const errorHandler = (err, req, res, next) => {
    console.error('API ERROR:', err);

    if (err instanceof ZodError) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: err.errors.map(e => ({
                field: e.path.join('.'),
                message: e.message
            }))
        });
    }

    if (err instanceof AppError) {
        return res.status(err.statusCode).json({
            success: false,
            message: err.message,
            ...(err.errors && { errors: err.errors })
        });
    }

    if (err.code === 'P2002') {
        return res.status(409).json({
            success: false,
            message: 'A record with this value already exists'
        });
    }

    if (err.code === 'P2025') {
        return res.status(404).json({
            success: false,
            message: 'Record not found'
        });
    }

    if (err.code === 'P2000') {
        return res.status(400).json({
            success: false,
            message: 'Input value is too long for one or more fields'
        });
    }

    return res.status(500).json({
        success: false,
        message: err.message || 'Internal server error',
        stack: err.stack,
        code: err.code
    });
};

export default errorHandler;
